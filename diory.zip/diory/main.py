import streamlit as st
import requests
import json
from datetime import datetime

# Hugging Face API 설정
API_URL = "https://api-inference.huggingface.co/models/facebook/blenderbot-400M-distill"
headers = {"Authorization": f"Bearer {st.secrets.get('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', '')}"}

def query_model(payload):
    """HuggingFace API에 요청을 보내는 함수"""
    try:
        response = requests.post(API_URL, headers=headers, json=payload)
        return response.json()
    except Exception as e:
        st.error(f"API 요청 중 오류가 발생했습니다: {str(e)}")
        return None

def generate_diary(conversation):
    """대화 내용을 바탕으로 일기 형식의 텍스트를 생성하는 함수"""
    prompt = {
        "inputs": f"다음 대화를 바탕으로 일기 형식의 글을 작성해줘: {conversation}"
    }
    response = query_model(prompt)
    if response and 'generated_text' in response:
        return response['generated_text']
    return "일기 생성 중 오류가 발생했습니다."

def main():
    st.title("🌟 AI와 함께 쓰는 일기")
    
    # 세션 상태 초기화
    if 'messages' not in st.session_state:
        st.session_state.messages = []
        st.session_state.conversation = []
    
    # 새로운 일기 시작 버튼
    if st.button("새로운 일기 시작"):
        st.session_state.messages = []
        st.session_state.conversation = []
        st.experimental_rerun()
    
    # 대화 히스토리 표시
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.write(message["content"])
    
    # 첫 질문 또는 사용자 입력이 없는 경우
    if not st.session_state.messages:
        with st.chat_message("assistant"):
            st.write("오늘 하루는 어땠나요?")
            st.session_state.messages.append({"role": "assistant", "content": "오늘 하루는 어땠나요?"})
    
    # 사용자 입력
    user_input = st.chat_input("여기에 답변을 입력하세요...")
    
    if user_input:
        # 사용자 메시지 추가
        st.session_state.messages.append({"role": "user", "content": user_input})
        st.session_state.conversation.append(f"User: {user_input}")
        
        # AI 응답 생성
        prompt = {
            "inputs": f"이전 대화를 바탕으로 더 자세히 물어볼 수 있는 질문을 해주세요: {user_input}"
        }
        response = query_model(prompt)
        
        if response and 'generated_text' in response:
            ai_message = response['generated_text']
            st.session_state.messages.append({"role": "assistant", "content": ai_message})
            st.session_state.conversation.append(f"Assistant: {ai_message}")
            st.experimental_rerun()
    
    # 일기 생성 버튼
    if st.button("일기 작성 완료"):
        if st.session_state.conversation:
            with st.spinner("일기를 생성하고 있습니다..."):
                diary_text = generate_diary("\n".join(st.session_state.conversation))
                st.markdown("### 📝 오늘의 일기")
                st.write(diary_text)
                
                # 일기 저장 옵션
                now = datetime.now().strftime("%Y%m%d_%H%M%S")
                st.download_button(
                    label="일기 저장하기",
                    data=diary_text,
                    file_name=f"diary_{now}.txt",
                    mime="text/plain"
                )
        else:
            st.warning("아직 대화가 없습니다. 먼저 대화를 나눠주세요!")

if __name__ == "__main__":
    main()