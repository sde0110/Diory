# AI 대화식 일기 작성 앱

AI와 대화하면서 일기를 작성하는 웹 애플리케이션입니다.

## 기능

- AI와의 대화를 통한 일기 작성
- 자연스러운 대화 흐름
- 일기 자동 생성
- 작성된 일기 텍스트 파일로 저장

## 설치 방법

1. 저장소를 클론합니다:
```bash
git clone <repository-url>
cd <repository-directory>
```

2. 필요한 패키지를 설치합니다:
```bash
pip install -r requirements.txt
```

3. HuggingFace API 키를 설정합니다:
   - [HuggingFace](https://huggingface.co/)에서 계정을 만들고 API 키를 발급받습니다.
   - `.streamlit/secrets.toml` 파일을 생성하고 다음 내용을 추가합니다:
```toml
HUGGINGFACE_API_KEY = "your-api-key-here"
```

## 실행 방법

다음 명령어로 앱을 실행합니다:
```bash
streamlit run main.py
```

## 사용 방법

1. "오늘 하루는 어땠나요?"라는 질문에 답변을 입력합니다.
2. AI가 후속 질문을 하면 계속해서 대화를 이어갑니다.
3. 대화가 충분히 이루어졌다면 "일기 작성 완료" 버튼을 클릭합니다.
4. 생성된 일기를 확인하고 필요한 경우 저장합니다.
5. "새로운 일기 시작" 버튼으로 새로운 일기를 작성할 수 있습니다. 